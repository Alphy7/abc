import { renderFooter } from "../component/footer.js";

const container2 = document.getElementById("footer-container");
container2.appendChild(renderFooter());


document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("login-form");
  const eyeIcon = document.getElementById("eye-icon");
  const passwordInput = document.getElementById("pass");

  // Toggle password visibility
  eyeIcon.addEventListener("click", () => {
    const isVisible = passwordInput.type === "text";
    passwordInput.type = isVisible ? "password" : "text";
    const eyeImg = eyeIcon.querySelector("img");
    eyeImg.src = isVisible
      ? "/assets/icons/preview.svg"
      : "/assets/icons/hide.svg";
  });

  // Validate radio group (login-type)
  form.addEventListener("submit", (event) => {
    const loginType = document.querySelector(
      'input[name="login-type"]:checked'
    );
    if (!loginType) {
      event.preventDefault();
      alert("Please select a login type.");
      document.querySelector('label[for="district-radio"]').focus();
    }
    // Let other fields use native HTML5 validation
  });
});
