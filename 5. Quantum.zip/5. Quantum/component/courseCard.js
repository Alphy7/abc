// components/CourseCard.js
export function createCourseCard(course) {
  const card = document.createElement('div');
  card.className = 'course-card';

  card.innerHTML = `
    ${course.expired ? '<div class="status-expired">EXPIRED</div>' : ''}
    <img class="star-icon" src="assets/${course.starred ? 'star-filled.svg' : 'star-empty.svg'}" alt="Star">
    
    <img src="${course.image}" alt="${course.title}">
    
    <div class="course-title">${course.title}</div>
    <div class="course-meta">${course.subject} | Grade ${course.grade}</div>
    <div class="course-meta">${course.units || 0} Units, ${course.lessons || 0} Lessons, ${course.topics || 0} Topics</div>
    <div class="course-meta">${course.teacher}</div>
    <div class="course-meta">${course.students ? course.students + ' Students' : ''}</div>
    <div class="course-meta">${course.startDate && course.endDate ? course.startDate + ' - ' + course.endDate : ''}</div>
    
    <div class="course-actions">
      <img src="assets/eye.svg" alt="View" title="View">
      <img src="assets/calendar.svg" alt="Calendar" title="Calendar">
      <img src="assets/clone.svg" alt="Clone" title="Clone">
      <img src="assets/chart.svg" alt="Report" title="Report">
    </div>
  `;

  return card;
}
