document.addEventListener("DOMContentLoaded", () => {
  const dataAnnounce = [
    {
      annName: "Wilson Kumar",
      title: "No classes will be held on 21st Nov",
      date: "15-Sep-2018 at 07:21 pm",
      files: 2,
      read: false,
    },
    {
      annName: "Samson White",
      title: "Guest lecture on Geometry on 20th September",
      date: "15-Sep-2018 at 07:21 pm",
      files: 2,
      read: false,
    },
    {
      annName: "Wilson Kumar",
      title: "Additional course materials available on request",
      courseClass: "Course: Mathematics 101",
      date: "15-Sep-2018 at 07:21 pm",
      read: true,
    },
    {
      annName: "Wilson Kumar",
      title: "No classes will be held on 25th Dec",
      date: "15-Sep-2018 at 07:21 pm",
      files: 1,
      read: true,
    },
    {
      annName: "Wilson Kumar",
      title: "Additional course materials available on request",
      courseClass: "Course: Mathematics 101",
      date: "15-Sep-2018 at 07:21 pm",
      read: true,
    },
    {
      annName: "Wilson Kumar",
      title: "Additional course materials available on request",
      courseClass: "Course: Mathematics 101",
      date: "15-Sep-2018 at 07:21 pm",
      read: true,
    },
    {
      annName: "Wilson Kumar",
      title: "No classes will be held on 25th Dec",
      date: "15-Sep-2018 at 07:21 pm",
      files: 1,
      read: true,
    },
    {
      annName: "Wilson Kumar",
      title: "Additional course materials available on request",
      courseClass: "Course: Mathematics 101",
      date: "15-Sep-2018 at 07:21 pm",
      read: true,
    },
  ];

  const announceContainer = document.getElementById("announcements-data");

  function renderAnnouncements() {
    announceContainer.innerHTML = dataAnnounce
      .map((item, index) => `
        <div class="${item.read ? '' : 'card-bg1'}" data-index="${index}">
          <div class="header-row">
            <p class="ann-name">PA: ${item.annName}</p>
            <img src="../assets/icons/${item.read ? 'tick' : 'untick'}.svg" 
                 alt="${item.read ? 'checkmark' : 'dnd'}" 
                 class="toggle-read">
          </div>
          <div class="ann-content">
            <p class="ann-title">${item.title}</p>
            ${item.courseClass ? `<p class="ann-course-class">${item.courseClass}</p>` : ''}
            <p class="files-date">
              <span class="files">
                ${item.files ? `<img src="../assets/icons/attachment.svg" alt="paperclip"> <span>${item.files} files are attached</span>` : ''}
              </span>
              <span class="date">${item.date}</span>
            </p>
          </div>
        </div>
      `)
      .join('');

    document.querySelectorAll(".toggle-read").forEach(icon => {
      icon.addEventListener("click", (e) => {
        const parent = e.target.closest("div[data-index]");
        const index = parent.getAttribute("data-index");
        dataAnnounce[index].read = !dataAnnounce[index].read;
        renderAnnouncements();
      });
    });
  }

  if (announceContainer) {
    renderAnnouncements();
  }
});

















document.addEventListener("DOMContentLoaded", () => {
  const alertData = [
    {
      title: "License for Introduction to Algebra has been assigned to your school",
      date: "15-Sep-2018 at 07:21 pm",
      read: false,
    },
    {
      title: "Lesson 3 Practice Worksheet overdue for Amy Santiago",
      course: "Course: Advanced Mathematics",
      date: "15-Sep-2018 at 05:21 pm",
      read: true,
    },
    {
      title: "23 new students created",
      date: "14-Sep-2018 at 01:21 pm",
      read: false,
    },
    {
      title: "15 submissions ready for evaluation",
      course: "Class: Basics of Algebra",
      date: "13-Sep-2018 at 01:15 pm",
      read: false,
    },
    {
      title: "License for Basic Concepts in Geometry has been assigned to your...",
      date: "15-Sep-2018 at 07:21 pm",
      read: false,
    },
    {
      title: "Lesson 3 Practice Worksheet overdue for Sam Diego",
      course: "Course: Advanced Mathematics",
      date: "15-Sep-2018 at 05:21 pm",
      read: true,
    },
    {
      title: "23 new students created",
      date: "14-Sep-2018 at 01:21 pm",
      read: false,
    },
    {
      title: "15 submissions ready for evaluation",
      course: "Class: Basics of Algebra",
      date: "13-Sep-2018 at 01:15 pm",
      read: false,
    },
    {
      title: "License for Basic Concepts in Geometry has been assigned to your...",
      date: "15-Sep-2018 at 07:21 pm",
      read: false,
    },
    {
      title: "Lesson 3 Practice Worksheet overdue for Sam Diego",
      course: "Course: Advanced Mathematics",
      date: "15-Sep-2018 at 05:21 pm",
      read: true,
    },
  ];

  const alertContainer = document.getElementById("alerts-data");

  function renderAlerts() {
    alertContainer.innerHTML = alertData
      .map((item, index) => `
        <div class="alert-card ${item.read ? '' : 'card-bg1'}" data-index="${index}">
          <div class="header-row">
            <p class="alert-title">${item.title}</p>
            <img src="../assets/icons/${item.read ? 'tick' : 'untick'}.svg"
                 alt="${item.read ? 'checkmark' : 'unread'}"
                 class="toggle-alert-read">
          </div>
          ${item.course ? `<p class="alert-course">${item.course}</p>` : ''}
          <p class="alert-date">${item.date}</p>
        </div>
      `)
      .join('');

    document.querySelectorAll(".toggle-alert-read").forEach(icon => {
      icon.addEventListener("click", (e) => {
        const parent = e.target.closest("div[data-index]");
        const index = parent.getAttribute("data-index");
        alertData[index].read = !alertData[index].read;
        renderAlerts();
      });
    });
  }

  if (alertContainer) {
    renderAlerts();
  }
});
