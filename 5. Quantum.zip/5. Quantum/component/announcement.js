let dataAnnounce = [];

export function loadAnnouncements(announceContainer) {
  if (!announceContainer) return;

  fetch('json/announcements.json')
    .then(response => response.json())
    .then(data => {
      dataAnnounce = data;
      renderAnnouncements(announceContainer);
      updateAnnouncementBubble(); // Update bubble after render
    })
    .catch(err => console.error('Error fetching announcements:', err));
}

function renderAnnouncements(announceContainer) {
  if (!announceContainer) return;

  announceContainer.innerHTML = dataAnnounce
    .map((item, index) => `
      <div class="${item.read ? '' : 'card-bg1'}" data-index="${index}">
        <div class="header-row">
          <p class="ann-name">PA: ${item.annName}</p>
          <img src="../assets/icons/${item.read ? 'tick' : 'untick'}.svg"
               alt="${item.read ? 'checkmark' : 'unread'}"
               class="toggle-read">
        </div>
        <div class="ann-content">
          <p class="ann-title">${item.title}</p>
          ${item.courseClass ? `<p class="ann-course-class">${item.courseClass}</p>` : ''}
          <p class="files-date">
            <span class="files">
              ${item.files ? `<img src="../assets/icons/attachment.svg" alt="attachment"> <span>${item.files} files are attached</span>` : ''}
            </span>
            <span class="date">${item.date}</span>
          </p>
        </div>
      </div>
    `)
    .join('');

  announceContainer.querySelectorAll(".toggle-read").forEach(icon => {
    icon.addEventListener("click", (e) => {
      const parent = e.target.closest("[data-index]");
      const index = parseInt(parent?.dataset.index, 10);
      if (!isNaN(index)) {
        dataAnnounce[index].read = !dataAnnounce[index].read;
        renderAnnouncements(announceContainer);
        updateAnnouncementBubble();
      }
    });
  });
}

function updateAnnouncementBubble() {
  const announcementBubble = document.getElementById("announcements-bubble");
  if (!announcementBubble) return;

  const unreadCount = dataAnnounce.filter(item => item.read).length;
  if (unreadCount > 0) {
    announcementBubble.textContent = unreadCount;
    announcementBubble.style.display = 'block';
  } else {
    announcementBubble.style.display = 'none';
  }
}