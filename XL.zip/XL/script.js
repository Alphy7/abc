import { Viewport } from "./script/viewport.js";
import { Renderer } from "./script/rederer.js";
import { DataManager } from "./script/data.js";
import { InputManager } from "./script/input.js";

const canvas = document.getElementById("spreadsheet-canvas");
const ctx = canvas.getContext("2d");
const wrapper = document.getElementById("wrapper");

const viewport = new Viewport();
const data = new DataManager();
const renderer = new Renderer(ctx, viewport, data);
const input = new InputManager(viewport, renderer, data);

function resizeCanvas() {
  viewport.updateSize();
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  renderer.drawGrid();
}

window.addEventListener("resize", resizeCanvas);

wrapper.addEventListener("scroll", () => {
  viewport.updateScroll(wrapper.scrollLeft, wrapper.scrollTop);
  renderer.drawGrid(input.selected);
});

resizeCanvas();
