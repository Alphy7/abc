export class DataManager {
  constructor() {
    this.data = new Map();
  }

  get(row, col) {
    return this.data.get(`${row},${col}`);
  }

  set(row, col, value) {
    this.data.set(`${row},${col}`, value);
  }
}
