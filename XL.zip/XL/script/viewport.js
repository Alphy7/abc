export class Viewport {
  constructor() {
    this.scrollX = 0;
    this.scrollY = 0;
    this.width = window.innerWidth;
    this.height = window.innerHeight;
  }
  updateSize() {
    this.width = window.innerWidth;
    this.height = window.innerHeight;
  }
  updateScroll(x, y) {
    this.scrollX = x;
    this.scrollY = y;
  }
}
