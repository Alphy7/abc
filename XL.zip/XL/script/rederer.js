import { CONFIG } from "./config.js";

export class Renderer {
  constructor(ctx, viewport, data) {
    this.data = data;
    this.ctx = ctx;
    this.viewport = viewport;
    this.dpr = window.devicePixelRatio || 1;
    this.calculateHeaderWidth();
  }

  calculateHeaderWidth() {
    this.ctx.font = CONFIG.font;
    const text = CONFIG.numRows.toString();
    const width = this.ctx.measureText(text).width;
    this.rowHeaderWidth = Math.ceil(width + CONFIG.padding * 2);
  }

  drawGrid(selected = null) {
    const { ctx } = this;
    const { scrollX, scrollY, width, height } = this.viewport;
    const startCol = Math.floor(scrollX / CONFIG.cellWidth);
    const startRow = Math.floor(scrollY / CONFIG.cellHeight);
    const endCol = Math.min(
      CONFIG.numCols - 1,
      Math.ceil((scrollX + width - this.rowHeaderWidth) / CONFIG.cellWidth)
    );
    const endRow = Math.min(
      CONFIG.numRows - 1,
      Math.ceil((scrollY + height - CONFIG.cellHeight) / CONFIG.cellHeight)
    );

    ctx.clearRect(0, 0, width, height);

    if (selected && selected.type !== 'cell') {
      this.drawSelectionHighlights(selected, startCol, endCol, startRow, endRow);
    }

    this.drawGridLines(startCol, endCol, startRow, endRow);
    this.drawCellContent(startCol, endCol, startRow, endRow);
    this.drawHeaders(startCol, endCol, startRow, endRow);

    if (selected) {
      this.drawSelectionEffects(selected);
    }
  }

  drawSelectionHighlights(selected, startCol, endCol, startRow, endRow) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY, width, height } = viewport;

    if (!selected) return;

    const lightBlue = 'rgba(184, 204, 228, 0.5)';
    const lightGreen = 'rgba(198, 239, 206, 0.7)';

    if (selected.type === 'all') {
      ctx.fillStyle = lightGreen;
      ctx.fillRect(rowHeaderWidth, CONFIG.cellHeight, width - rowHeaderWidth, height - CONFIG.cellHeight);
    }
  }

  drawGridLines(startCol, endCol, startRow, endRow) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY, width, height } = viewport;

    ctx.strokeStyle = '#D4D4D4';
    ctx.lineWidth = 1;

    // Vertical lines
    for (let col = startCol; col <= endCol + 1; col++) {
      const x = viewport.alignToPixel(rowHeaderWidth + col * CONFIG.cellWidth - scrollX);
      if (x >= rowHeaderWidth && x <= width) {
        ctx.beginPath();
        ctx.moveTo(x, CONFIG.cellHeight);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
    }

    // Horizontal lines
    for (let row = startRow; row <= endRow + 1; row++) {
      const y = viewport.alignToPixel(CONFIG.cellHeight + row * CONFIG.cellHeight - scrollY);
      if (y >= CONFIG.cellHeight && y <= height) {
        ctx.beginPath();
        ctx.moveTo(rowHeaderWidth, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    }
  }

  drawCellContent(startCol, endCol, startRow, endRow) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY } = viewport;

    ctx.fillStyle = '#000';
    ctx.font = CONFIG.font;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";

    for (let row = startRow; row <= endRow; row++) {
      for (let col = startCol; col <= endCol; col++) {
        const x = col * CONFIG.cellWidth - scrollX + rowHeaderWidth;
        const y = row * CONFIG.cellHeight - scrollY + CONFIG.cellHeight;
        const val = this.data?.get(row, col);

        if (val && x + CONFIG.cellWidth > rowHeaderWidth && x < viewport.width) {
          ctx.fillText(val, x + 5, y + CONFIG.cellHeight / 2);
        }
      }
    }
  }

  drawHeaders(startCol, endCol, startRow, endRow) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY, width, height } = viewport;

    // Header background
    const headerBg = '#F2F2F2';
    ctx.fillStyle = headerBg;
    ctx.fillRect(rowHeaderWidth, 0, width - rowHeaderWidth, CONFIG.cellHeight);
    ctx.fillRect(0, CONFIG.cellHeight, rowHeaderWidth, height - CONFIG.cellHeight);

    // Header borders
    ctx.strokeStyle = '#BEBEBE';
    ctx.lineWidth = 1;
    
    // Top header border
    ctx.beginPath();
    ctx.moveTo(0, CONFIG.cellHeight);
    ctx.lineTo(width, CONFIG.cellHeight);
    ctx.stroke();
    
    // Left header border
    ctx.beginPath();
    ctx.moveTo(rowHeaderWidth, 0);
    ctx.lineTo(rowHeaderWidth, height);
    ctx.stroke();

    // Header text
    ctx.fillStyle = '#000';
    ctx.font = CONFIG.headerFont;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // Column headers
    for (let col = startCol; col <= endCol; col++) {
      const x = rowHeaderWidth + col * CONFIG.cellWidth - scrollX;
      if (x + CONFIG.cellWidth > rowHeaderWidth && x < width) {
        const label = this.getColumnLabel(col);
        ctx.fillText(label, x + CONFIG.cellWidth / 2, CONFIG.cellHeight / 2);

        // Vertical separator
        const xSep = viewport.alignToPixel(x + CONFIG.cellWidth);
        if (xSep <= width) {
          ctx.beginPath();
          ctx.moveTo(xSep, 0);
          ctx.lineTo(xSep, CONFIG.cellHeight);
          ctx.stroke();
        }
      }
    }

    // Row headers
    for (let row = startRow; row <= endRow; row++) {
      const y = CONFIG.cellHeight + row * CONFIG.cellHeight - scrollY;
      if (y + CONFIG.cellHeight > CONFIG.cellHeight && y < height) {
        ctx.fillText(row + 1, rowHeaderWidth / 2, y + CONFIG.cellHeight / 2);

        // Horizontal separator
        const ySep = viewport.alignToPixel(y + CONFIG.cellHeight);
        if (ySep <= height) {
          ctx.beginPath();
          ctx.moveTo(0, ySep);
          ctx.lineTo(rowHeaderWidth, ySep);
          ctx.stroke();
        }
      }
    }

    // Top-left corner
    ctx.fillStyle = headerBg;
    ctx.fillRect(0, 0, rowHeaderWidth, CONFIG.cellHeight);
    ctx.strokeStyle = '#BEBEBE';
    ctx.strokeRect(0, 0, rowHeaderWidth, CONFIG.cellHeight);
  }

  drawSelectionEffects(selected) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY, width, height } = viewport;

    if (selected.type === 'cell') {
      this.drawCellSelection(selected);
      this.drawHeaderUnderline(selected);
    } else if (selected.type === 'row') {
      this.drawRowSelection(selected);
      this.drawAllColumnHeaderUnderlines();
    } else if (selected.type === 'column') {
      this.drawColumnSelection(selected);
      this.drawAllRowHeaderUnderlines();
    } else if (selected.type === 'all') {
      this.drawAllSelection();
    }
  }

  drawCellSelection(selected) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY } = viewport;
    const { row, col } = selected;
    const x = col * CONFIG.cellWidth - scrollX + rowHeaderWidth;
    const y = row * CONFIG.cellHeight - scrollY + CONFIG.cellHeight;
    ctx.save();
    ctx.strokeStyle = '#107C10';
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, CONFIG.cellWidth - 2, CONFIG.cellHeight - 2);
    ctx.restore();
  }

  drawRowSelection(selected) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollY } = viewport;

    const y = selected.row * CONFIG.cellHeight - scrollY + CONFIG.cellHeight;
    if (y + CONFIG.cellHeight > CONFIG.cellHeight && y < viewport.height) {
      ctx.fillStyle = '#107C10';
      ctx.fillRect(0, y, rowHeaderWidth, CONFIG.cellHeight);
      ctx.fillStyle = '#FFF';
      ctx.font = 'bold ' + CONFIG.headerFont;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(selected.row + 1, rowHeaderWidth / 2, y + CONFIG.cellHeight / 2);
    }
  }

  drawColumnSelection(selected) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX } = viewport;
    const x = selected.col * CONFIG.cellWidth - scrollX + rowHeaderWidth;

    if (x + CONFIG.cellWidth > rowHeaderWidth && x < viewport.width) {
      ctx.fillStyle = '#107C10';
      ctx.fillRect(x, 0, CONFIG.cellWidth, CONFIG.cellHeight);
      ctx.fillStyle = '#FFF';
      ctx.font = 'bold ' + CONFIG.headerFont;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const colLabel = this.getColumnLabel(selected.col);
      ctx.fillText(colLabel, x + CONFIG.cellWidth / 2, CONFIG.cellHeight / 2);
    }
  }

  drawHeaderUnderline(selected) {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, scrollY } = viewport;
    ctx.save();
    ctx.strokeStyle = '#107C10';
    ctx.lineWidth = 2;
    const x = selected.col * CONFIG.cellWidth - scrollX + rowHeaderWidth;
    if (x + CONFIG.cellWidth > rowHeaderWidth && x < viewport.width) {
      ctx.beginPath();
      ctx.moveTo(x, CONFIG.cellHeight - 2);
      ctx.lineTo(x + CONFIG.cellWidth, CONFIG.cellHeight - 2);
      ctx.stroke();
    }
    const y = selected.row * CONFIG.cellHeight - scrollY + CONFIG.cellHeight;
    if (y + CONFIG.cellHeight > CONFIG.cellHeight && y < viewport.height) {
      ctx.beginPath();
      ctx.moveTo(rowHeaderWidth - 2, y);
      ctx.lineTo(rowHeaderWidth - 2, y + CONFIG.cellHeight);
      ctx.stroke();
    }
    ctx.restore();
  }

  drawAllColumnHeaderUnderlines() {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollX, width } = viewport;
    ctx.save();
    ctx.strokeStyle = '#107C10';
    ctx.lineWidth = 2;
    const startCol = Math.floor(scrollX / CONFIG.cellWidth);
    const endCol = Math.min(
      CONFIG.numCols - 1,
      Math.ceil((scrollX + width - rowHeaderWidth) / CONFIG.cellWidth)
    );
    for (let col = startCol; col <= endCol; col++) {
      const x = rowHeaderWidth + col * CONFIG.cellWidth - scrollX;
      if (x + CONFIG.cellWidth > rowHeaderWidth && x < width) {
        ctx.beginPath();
        ctx.moveTo(x, CONFIG.cellHeight - 2);
        ctx.lineTo(x + CONFIG.cellWidth, CONFIG.cellHeight - 2);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  drawAllRowHeaderUnderlines() {
    const { ctx, viewport, rowHeaderWidth } = this;
    const { scrollY, height } = viewport;
    ctx.save();
    ctx.strokeStyle = '#107C10';
    ctx.lineWidth = 2;
    const startRow = Math.floor(scrollY / CONFIG.cellHeight);
    const endRow = Math.min(
      CONFIG.numRows - 1,
      Math.ceil((scrollY + height - CONFIG.cellHeight) / CONFIG.cellHeight)
    );
    for (let row = startRow; row <= endRow; row++) {
      const y = CONFIG.cellHeight + row * CONFIG.cellHeight - scrollY;
      if (y + CONFIG.cellHeight > CONFIG.cellHeight && y < height) {
        ctx.beginPath();
        ctx.moveTo(rowHeaderWidth - 2, y);
        ctx.lineTo(rowHeaderWidth - 2, y + CONFIG.cellHeight);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  drawAllSelection() {
    const { ctx, rowHeaderWidth } = this;

    ctx.fillStyle = '#107C10';
    ctx.fillRect(0, 0, rowHeaderWidth, CONFIG.cellHeight);
    
    this.drawAllColumnHeaderUnderlines();
    this.drawAllRowHeaderUnderlines();
  }

  getColumnLabel(index) {
    let label = "";
    while (index >= 0) {
      label = String.fromCharCode((index % 26) + 65) + label;
      index = Math.floor(index / 26) - 1;
    }
    return label;
  }
}