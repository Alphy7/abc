
import { CONFIG } from "../config.js";

export class SelectionManager {
  constructor(viewport, renderer, data) {
    this.viewport = viewport;
    this.renderer = renderer;
    this.data = data;
    this.selected = null;
    this.isEditing = false;
    this.editor = document.getElementById("cell-editor");
  }

  getCellFromMouse(x, y) {
    const { scrollX, scrollY } = this.viewport;
    const rowHeaderWidth = this.renderer.rowHeaderWidth;

    if (x < rowHeaderWidth && y < CONFIG.cellHeight) {
      return { type: 'corner' };
    } else if (y < CONFIG.cellHeight && x >= rowHeaderWidth) {
      const col = Math.floor((x + scrollX - rowHeaderWidth) / CONFIG.cellWidth);
      if (col >= 0 && col < CONFIG.numCols) {
        return { type: 'column', col };
      }
    } else if (x < rowHeaderWidth) {
      const row = Math.floor((y + scrollY - CONFIG.cellHeight) / CONFIG.cellHeight);
      if (row >= 0 && row < CONFIG.numRows) {
        return { type: 'row', row };
      }
    } else {
      const col = Math.floor((x + scrollX - rowHeaderWidth) / CONFIG.cellWidth);
      const row = Math.floor((y + scrollY - CONFIG.cellHeight) / CONFIG.cellHeight);
      if (row >= 0 && row < CONFIG.numRows && col >= 0 && col < CONFIG.numCols) {
        return { type: 'cell', row, col };
      }
    }
    return null;
  }

  selectCell(row, col, edit = false) {
    if (row == null || col == null || row < 0 || col < 0 || 
        row >= CONFIG.numRows || col >= CONFIG.numCols) {
      return;
    }

    this.selected = { type: 'cell', row, col };
    this.isEditing = edit;
    this.renderer.drawGrid(this.selected);
    if (!edit && this.editor) {
      this.editor.blur();
    }
  }

  selectRow(row) {
    if (row == null || row < 0 || row >= CONFIG.numRows) {
      return;
    }

    this.selected = { type: 'row', row };
    this.isEditing = false;
    this.renderer.drawGrid(this.selected);
  }

  selectColumn(col) {
    if (col == null || col < 0 || col >= CONFIG.numCols) {
      return;
    }

    this.selected = { type: 'column', col };
    this.isEditing = false;
    this.renderer.drawGrid(this.selected);
  }

  selectAll() {
    this.selected = { type: 'all' };
    this.isEditing = false;
    this.renderer.drawGrid(this.selected);
  }

  clearSelection() {
    this.selected = null;
    this.isEditing = false;
    this.renderer.drawGrid();
  }

  getSelection() {
    return this.selected;
  }
}