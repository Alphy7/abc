import { CONFIG } from "../config.js";

export function getColEdge(x, y, renderer, viewport) {
  const { scrollX } = viewport;
  const rowHeaderWidth = renderer.rowHeaderWidth;
  let col = -1;
  for (let c = 0; c < CONFIG.numCols; c++) {
    const colX = rowHeaderWidth + c * CONFIG.cellWidth - scrollX;
    if (Math.abs(x - (colX + CONFIG.cellWidth)) < 4 && y < CONFIG.cellHeight) {
      col = c;
      break;
    }
  }
  return col;
}

export function getRowEdge(x, y, renderer, viewport) {
  const { scrollY } = viewport;
  const rowHeaderWidth = renderer.rowHeaderWidth;
  let row = -1;
  for (let r = 0; r < CONFIG.numRows; r++) {
    const rowY = CONFIG.cellHeight + r * CONFIG.cellHeight - scrollY;
    if (Math.abs(y - (rowY + CONFIG.cellHeight)) < 4 && x < rowHeaderWidth) {
      row = r;
      break;
    }
  }
  return row;
}