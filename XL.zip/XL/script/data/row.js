import { CONFIG } from "../config.js";

export class row {
  constructor() {
    this.rowHeight = new Map();
  }

  set(row, value) {
    const key = `R${row}`;
    if (value === "" || value == null) {
      this.rowHeight.delete(key);
    } else {
      this.rowHeight.set(key, value);
    }
  }

  get(row) {
    const key = `R${row}F`;
    return (this.rowHeight.get(key) || CONFIG.cellHeight) > 5 ? (this.rowHeight.get(key) || CONFIG.cellHeight) : 5;
  }
}
