import { CONFIG } from "../config.js";

export class column {
  constructor() {
    this.colWidth = new Map();
  }

  set(col, value) {
    const key = `R${col}`;
    if (value === "" || value == null) {
      this.colWidth.delete(key);
    } else {
      this.colWidth.set(key, value);
    }
  }

  get(col) {
    const key = `R${col}F`;
    return (this.colWidth.get(key) || CONFIG.cellWidth) > 5 ? (this.colWidth.get(key) || CONFIG.cellWidth) : 5;
  }
}
