export class column {
    
}