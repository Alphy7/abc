// CONFIG DATA
class Config {
  static DEFAULT_CELL_WIDTH = 100;
  static DEFAULT_CELL_HEIGHT = 30;
  static HEADER_HEIGHT = 30;
  static HEADER_WIDTH = 50;
  static ROWS = 100;
  static COLS = 40;
  static RESIZE_THRESHOLD = 6;
  static MIN_CELL_WIDTH = 30;
  static MIN_CELL_HEIGHT = 20;
  static COLORS = {
    CELL_BACKGROUND: "#ffffff",
    CELL_BORDER: "#e0e0e0",
    CELL_TEXT: "black",
    HEADER_BACKGROUND: "#f5f5f5",
    HEADER_TEXT: "black",
    SELECTION_BORDER: "#137e43",
    SELECTED_CELL_HEADER_BACKGROUND: "#caead8",
    SELECTED_CELL_HEADER_SHADOW: "#137e43",
    SELECTED_HEADER: "#137e43",
    SELECTED_HEADER_TEXT: "white",
  };
}

// UTILITY FUNCTIONS
class Utils {
  static getColLabel(index) {
    let label = "";
    while (index >= 0) {
      label = String.fromCharCode((index % 26) + 65) + label;
      index = Math.floor(index / 26) - 1;
    }
    return label;
  }
}

// DATA HANDLING
class Data {
  constructor(rows, cols) {
    this.rows = rows;
    this.cols = cols;
    this.data = Array.from({ length: rows }, () => Array(cols).fill(""));
  }
  get(r, c) {
    return this.data[r]?.[c] ?? "";
  }
  set(r, c, v) {
    if (this.data[r]) this.data[r][c] = v;
  }
  storeData(cell, value) {
    this.set(cell.row, cell.col, value);
  }
  retrieveData(cell) {
    return this.get(cell.row, cell.col);
  }
}

// ROWS and COLUMNS: *Own resizing and dimension logic* and expose clean APIs.
class Rows {
  constructor(spreadsheet) {
    this.sheet = spreadsheet;
    this.heights = Array(Config.ROWS).fill(Config.DEFAULT_CELL_HEIGHT);
    this.resizing = null;
  }
  getHeight(row) {
    return this.heights[row];
  }
  resizeRow(row, newHeight) {
    this.heights[row] = Math.max(Config.MIN_CELL_HEIGHT, newHeight);
    this.sheet.render.renderGrid();
  }
  findRowByY(y, scrollRow) {
    let py = Config.HEADER_HEIGHT;
    for (let i = scrollRow; i < Config.ROWS; i++) {
      let h = this.heights[i];
      if (y >= py && y < py + h) return i;
      py += h;
    }
    return null;
  }
  findRowEdge(y, scrollRow) {
    let py = Config.HEADER_HEIGHT;
    for (let i = scrollRow; i < Config.ROWS; i++) {
      let h = this.heights[i];
      if (Math.abs(y - (py + h)) < Config.RESIZE_THRESHOLD) return i;
      py += h;
    }
    return null;
  }
}

class Columns {
  constructor(spreadsheet) {
    this.sheet = spreadsheet;
    this.widths = Array(Config.COLS).fill(Config.DEFAULT_CELL_WIDTH);
    this.resizing = null;
  }
  getWidth(col) {
    return this.widths[col];
  }
  resizeCol(col, newWidth) {
    this.widths[col] = Math.max(Config.MIN_CELL_WIDTH, newWidth);
    this.sheet.render.renderGrid();
  }
  findColByX(x, scrollCol) {
    let px = Config.HEADER_WIDTH;
    for (let i = scrollCol; i < Config.COLS; i++) {
      let w = this.widths[i];
      if (x >= px && x < px + w) return i;
      px += w;
    }
    return null;
  }
  findColEdge(x, scrollCol) {
    let px = Config.HEADER_WIDTH;
    for (let i = scrollCol; i < Config.COLS; i++) {
      let w = this.widths[i];
      if (Math.abs(x - (px + w)) < Config.RESIZE_THRESHOLD) return i;
      px += w;
    }
    return null;
  }
}

// CELL CLASS
class Cell {
  constructor(x, y, spreadsheet) {
    this.x = x;
    this.y = y;
    this.sheet = spreadsheet;
  }
  get value() {
    return this.sheet.data.get(this.x, this.y);
  }
  set value(val) {
    this.sheet.data.set(this.x, this.y, val);
  }
  handleClick() {
    this.sheet.selection.selectCell(this.x, this.y);
    this.sheet.render.renderGrid();
    this.sheet.input.updateInputForCell(this.x, this.y);
  }
}

// SELECTION
class Selection {
  constructor(spreadsheet) {
    this.sheet = spreadsheet;
    this.clearSelection();
  }

  selectCell(row, col) {
    this.start = { row, col };
    this.end = { row, col };
    this.active = true;
    this.selectedCells = [{ row, col }];
    this.sheet.input.updateInputForCell(row, col); // Start editing the selected cell
  }

  selectRange(startRow, startCol, endRow, endCol) {
    this.start = { row: startRow, col: startCol };
    this.end = { row: endRow, col: endCol };
    this.active = true;
    this.selectedCells = [];
    for (let r = startRow; r <= endRow; r++) {
      for (let c = startCol; c <= endCol; c++) {
        this.selectedCells.push({ row: r, col: c });
      }
    }
    this.sheet.input.updateInputForCell(endRow, endCol); // Start editing the last cell in the range
  }

  getSelectedCells() {
    return this.selectedCells;
  }

  isCellSelected(r, c) {
    return this.selectedCells.some(cell => cell.row === r && cell.col === c);
  }

  get focusCell() {
    return this.end;
  }

  clearSelection() {
    this.start = { row: 0, col: 0 };
    this.end = { row: 0, col: 0 };
    this.selectedCells = [];
    this.active = false;
  }
}

// INPUT HANDLER: Only manages input, formula bar, commit, and focus!
class Input {
  constructor(spreadsheet) {
    this.sheet = spreadsheet;
    // Create overlay input
    this.inputElem = document.createElement("input");
    this.inputElem.id = "cell-input";
    document.getElementById("container").appendChild(this.inputElem);

    // Listeners for handling Enter, Tab, Arrow keys, etc.
    this.inputElem.addEventListener("keydown", (e) => {
      let { row, col } = this.activeCell || this.sheet.selection.focusCell;
      let handled = false;

      // Handling Arrow keys, Enter, and Tab
      if (
        ["Enter", "Tab", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(e.key)
      ) {
        // Commit the current cell's value
        this.commit();

        let dr = 0, dc = 0;
        if (e.key === "Enter") dr = e.shiftKey ? -1 : 1; // Move down (or up if Shift + Enter)
        if (e.key === "Tab") dc = e.shiftKey ? -1 : 1; // Move right (or left if Shift + Tab)
        if (e.key === "ArrowUp") dr = -1; // Move up
        if (e.key === "ArrowDown") dr = 1; // Move down
        if (e.key === "ArrowLeft") dc = -1; // Move left
        if (e.key === "ArrowRight") dc = 1; // Move right

        let nr = Math.min(Math.max(row + dr, 0), Config.ROWS - 1); // Next row, bound by number of rows
        let nc = Math.min(Math.max(col + dc, 0), Config.COLS - 1); // Next column, bound by number of columns

        // Select the next cell
        this.sheet.selection.selectCell(nr, nc);
        this.sheet.render.renderGrid(); // Redraw the grid to show the updated selection

        // Start editing the next cell
        this.showInput(nr, nc); // Automatically start editing the next cell

        // Prevent the default behavior (e.g., scrolling, moving to the next field)
        e.preventDefault();
        handled = true;
      }

      // If Escape is pressed, cancel editing
      if (e.key === "Escape") {
        this.hideInput();
        e.preventDefault();
      }
    });

    this.inputElem.addEventListener("blur", () => this.commit());
  }

  // Method to show the input at the correct position
  showInput(row, col) {
    const vp = this.sheet.viewport;
    const x = vp.colX(col);
    const y = vp.rowY(row);
    const w = this.sheet.columns.getWidth(col) - 2;
    const h = this.sheet.rows.getHeight(row) - 2;

    Object.assign(this.inputElem.style, {
      left: x + "px",
      top: y + "px",
      width: w + "px",
      height: h + "px",
      display: "block",
    });
    this.inputElem.value = this.sheet.data.get(row, col);
    this.inputElem.focus();
    this.inputElem.select();
    this.activeCell = { row, col };
  }

  // Method to hide the input box
  hideInput() {
    this.inputElem.style.display = "none";
    this.activeCell = null;
  }

  // Method to update input for a specific cell
  updateInputForCell(row, col) {
    if (this.inputElem.style.display === "block") this.showInput(row, col);
  }

  // Method to commit the value to the cell
  commit() {
    if (!this.activeCell) return;
    let { row, col } = this.activeCell;
    let old = this.sheet.data.get(row, col);
    let val = this.inputElem.value;
    if (old !== val) {
      this.sheet.data.set(row, col, val);
      this.sheet.history.push({ row, col, old, val });
    }
    this.sheet.render.renderGrid();
    this.hideInput();
  }
}

// HISTORY
class History {
  constructor() {
    this.stack = [];
    this.redoStack = [];
  }
  push(cmd) {
    this.stack.push(cmd);
    this.redoStack = [];
  }
  undo(sheet) {
    if (this.stack.length === 0) return null;
    let cmd = this.stack.pop();
    this.redoStack.push(cmd);
    if (cmd.type === "paste") {
      // batch undo
      for (let c of cmd.cells) {
        sheet.data.set(c.row, c.col, c.old);
      }
    } else {
      sheet.data.set(cmd.row, cmd.col, cmd.old);
    }
    sheet.render.renderGrid();
    return cmd;
  }
  redo(sheet) {
    if (this.redoStack.length === 0) return null;
    let cmd = this.redoStack.pop();
    this.stack.push(cmd);
    if (cmd.type === "paste") {
      for (let c of cmd.cells) {
        sheet.data.set(c.row, c.col, c.val);
      }
    } else {
      sheet.data.set(cmd.row, cmd.col, cmd.val);
    }
    sheet.render.renderGrid();
    return cmd;
  }
  clear() {
    this.stack = [];
    this.redoStack = [];
  }
}

// CLIPBOARD
class Clipboard {
  static async copy(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      window._internalClipboard = text;
    }
  }
  static async paste() {
    try {
      return await navigator.clipboard.readText();
    } catch {
      return window._internalClipboard || "";
    }
  }
  copy(cells, sheet) {
    let text = "";
    if (cells.length === 1) {
      let cell = cells[0];
      text = sheet.data.get(cell.row, cell.col);
    } else {
      let minRow = Math.min(...cells.map((c) => c.row)),
        maxRow = Math.max(...cells.map((c) => c.row));
      let minCol = Math.min(...cells.map((c) => c.col)),
        maxCol = Math.max(...cells.map((c) => c.col));
      let out = [];
      for (let r = minRow; r <= maxRow; r++) {
        let row = [];
        for (let c = minCol; c <= maxCol; c++) row.push(sheet.data.get(r, c));
        out.push(row.join("\t"));
      }
      text = out.join("\n");
    }
    Clipboard.copy(text);
  }
  async paste(targetCell, sheet) {
    let text = await Clipboard.paste();
    let lines = text.split("\n");
    let batch = [];
    for (let r = 0; r < lines.length; r++) {
      let vals = lines[r].split("\t");
      for (let c = 0; c < vals.length; c++) {
        let rr = targetCell.row + r,
          cc = targetCell.col + c;
        if (rr < Config.ROWS && cc < Config.COLS) {
          let old = sheet.data.get(rr, cc);
          batch.push({ row: rr, col: cc, old, val: vals[c] });
          sheet.data.set(rr, cc, vals[c]);
        }
      }
    }
    if (batch.length > 1) {
      sheet.history.push({ type: "paste", cells: batch });
    } else if (batch.length === 1) {
      sheet.history.push(batch[0]);
    }
    sheet.render.renderGrid();
  }
}

// VIEWPORT
class Viewport {
  constructor(canvas, spreadsheet) {
    this.canvas = canvas;
    this.sheet = spreadsheet;
  }
  get visibleCols() {
    let w = this.canvas.width - Config.HEADER_WIDTH,
      sum = 0,
      count = 0;
    for (let i = this.sheet.scrollCol; i < Config.COLS && sum < w; i++) {
      sum += this.sheet.columns.getWidth(i);
      count++;
    }
    return count;
  }
  get visibleRows() {
    let h = this.canvas.height - Config.HEADER_HEIGHT,
      sum = 0,
      count = 0;
    for (let i = this.sheet.scrollRow; i < Config.ROWS && sum < h; i++) {
      sum += this.sheet.rows.getHeight(i);
      count++;
    }
    return count;
  }
  colX(col) {
    let x = Config.HEADER_WIDTH;
    for (let i = this.sheet.scrollCol; i < col; i++)
      x += this.sheet.columns.getWidth(i);
    return x;
  }
  rowY(row) {
    let y = Config.HEADER_HEIGHT;
    for (let i = this.sheet.scrollRow; i < row; i++)
      y += this.sheet.rows.getHeight(i);
    return y;
  }
  findColByX(x) {
    let px = Config.HEADER_WIDTH;
    for (let i = this.sheet.scrollCol; i < Config.COLS; i++) {
      let w = this.sheet.columns.getWidth(i);
      if (x >= px && x < px + w) return i;
      px += w;
    }
    return null;
  }
  findRowByY(y) {
    let py = Config.HEADER_HEIGHT;
    for (let i = this.sheet.scrollRow; i < Config.ROWS; i++) {
      let h = this.sheet.rows.getHeight(i);
      if (y >= py && y < py + h) return i;
      py += h;
    }
    return null;
  }
}

// RENDERER: only draws, gets sizes from Rows/Columns, does not manage logic
class Render {
  constructor(spreadsheet) {
    this.sheet = spreadsheet;
    this.viewport = spreadsheet.viewport;
    this.canvas = spreadsheet.canvas;
    this.ctx = this.canvas.getContext("2d");
  }
  renderGrid() {
    let ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    let sheet = this.sheet,
      vp = this.viewport;
    // Col headers
    let colx = Config.HEADER_WIDTH;
    for (
      let c = sheet.scrollCol, i = 0;
      i < vp.visibleCols && c < Config.COLS;
      c++, i++
    ) {
      let w = sheet.columns.getWidth(c);
      ctx.fillStyle = Config.COLORS.HEADER_BACKGROUND;
      ctx.fillRect(colx, 0, w, Config.HEADER_HEIGHT);
      ctx.strokeStyle = Config.COLORS.CELL_BORDER;
      ctx.strokeRect(colx, 0, w, Config.HEADER_HEIGHT);
      ctx.fillStyle = Config.COLORS.HEADER_TEXT;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.font = "bold 15px Segoe UI, Arial";
      ctx.fillText(
        Utils.getColLabel(c),
        colx + w / 2,
        Config.HEADER_HEIGHT / 2
      );
      colx += w;
    }
    // Row headers
    let rowy = Config.HEADER_HEIGHT;
    for (
      let r = sheet.scrollRow, i = 0;
      i < vp.visibleRows && r < Config.ROWS;
      r++, i++
    ) {
      let h = sheet.rows.getHeight(r);
      ctx.fillStyle = Config.COLORS.HEADER_BACKGROUND;
      ctx.fillRect(0, rowy, Config.HEADER_WIDTH, h);
      ctx.strokeStyle = Config.COLORS.CELL_BORDER;
      ctx.strokeRect(0, rowy, Config.HEADER_WIDTH, h);
      ctx.fillStyle = Config.COLORS.HEADER_TEXT;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.font = "bold 15px Segoe UI, Arial";
      ctx.fillText(r + 1, Config.HEADER_WIDTH / 2, rowy + h / 2);
      rowy += h;
    }
    // Corner header
    ctx.fillStyle = Config.COLORS.HEADER_BACKGROUND;
    ctx.fillRect(0, 0, Config.HEADER_WIDTH, Config.HEADER_HEIGHT);
    ctx.strokeStyle = Config.COLORS.CELL_BORDER;
    ctx.strokeRect(0, 0, Config.HEADER_WIDTH, Config.HEADER_HEIGHT);

    // Draw cells
    rowy = Config.HEADER_HEIGHT;
    for (
      let r = sheet.scrollRow, i = 0;
      i < vp.visibleRows && r < Config.ROWS;
      r++, i++
    ) {
      let h = sheet.rows.getHeight(r),
        colx = Config.HEADER_WIDTH;
      for (
        let c = sheet.scrollCol, j = 0;
        j < vp.visibleCols && c < Config.COLS;
        c++, j++
      ) {
        let w = sheet.columns.getWidth(c);
        // Selected?
        if (sheet.selection.isCellSelected(r, c)) {
          ctx.fillStyle = "#e9ffe5";
          ctx.fillRect(colx, rowy, w, h);
        } else {
          ctx.fillStyle = Config.COLORS.CELL_BACKGROUND;
          ctx.fillRect(colx, rowy, w, h);
        }
        ctx.strokeStyle = Config.COLORS.CELL_BORDER;
        ctx.strokeRect(colx, rowy, w, h);
        ctx.fillStyle = Config.COLORS.CELL_TEXT;
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";
        ctx.font = "14px Segoe UI, Arial";
        let val = sheet.data.get(r, c);
        if (val) ctx.fillText(val, colx + 5, rowy + h / 2);

        // Excel green border for selection/focus
        if (
          sheet.selection.active &&
          sheet.selection.focusCell.row === r &&
          sheet.selection.focusCell.col === c
        ) {
          ctx.save();
          ctx.strokeStyle = Config.COLORS.SELECTION_BORDER;
          ctx.lineWidth = 2;
          ctx.strokeRect(colx + 1, rowy + 1, w - 2, h - 2);
          ctx.restore();
        }
        colx += w;
      }
      rowy += h;
    }
  }
}

// --- Spreadsheet: orchestrator only
class Spreadsheet {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext("2d");
    this.scrollRow = 0;
    this.scrollCol = 0;
    this.data = new Data(Config.ROWS, Config.COLS);
    this.rows = new Rows(this);
    this.columns = new Columns(this);
    this.selection = new Selection(this);
    this.input = new Input(this);
    this.history = new History();
    this.clipboard = new Clipboard();
    this.viewport = new Viewport(this.canvas, this);
    this.render = new Render(this);
    this.attachUI();
    this.render.renderGrid();
  }
  attachUI() {
    // Undo/redo buttons
    document.getElementById("undoBtn").onclick = () => this.history.undo(this);
    document.getElementById("redoBtn").onclick = () => this.history.redo(this);

    // Event manager (keyboard, mouse)
    const eventManager = new EventManager(this.canvas, this);
    eventManager.attachEvents();

    // Row/Col resizing: click on edge, drag
    this.canvas.addEventListener("mousedown", (e) => {
      let rect = this.canvas.getBoundingClientRect();
      let mx = e.clientX - rect.left,
        my = e.clientY - rect.top;
      // Column edge?
      if (my <= Config.HEADER_HEIGHT && mx > Config.HEADER_WIDTH) {
        let col = this.columns.findColEdge(mx, this.scrollCol);
        if (col !== null) {
          this.columns.resizing = {
            col,
            startX: mx,
            orig: this.columns.getWidth(col),
          };
          document.body.style.cursor = "col-resize";
        }
      }
      // Row edge?
      if (mx <= Config.HEADER_WIDTH && my > Config.HEADER_HEIGHT) {
        let row = this.rows.findRowEdge(my, this.scrollRow);
        if (row !== null) {
          this.rows.resizing = {
            row,
            startY: my,
            orig: this.rows.getHeight(row),
          };
          document.body.style.cursor = "row-resize";
        }
      }
    });
    window.addEventListener("mousemove", (e) => {
      // Col resize
      if (this.columns.resizing) {
        let rect = this.canvas.getBoundingClientRect();
        let mx = e.clientX - rect.left;
        let { col, startX, orig } = this.columns.resizing;
        let newWidth = orig + (mx - startX);
        this.columns.resizeCol(col, newWidth);
      }
      // Row resize
      if (this.rows.resizing) {
        let rect = this.canvas.getBoundingClientRect();
        let my = e.clientY - rect.top;
        let { row, startY, orig } = this.rows.resizing;
        let newHeight = orig + (my - startY);
        this.rows.resizeRow(row, newHeight);
      }
    });
    window.addEventListener("mouseup", () => {
      if (this.columns.resizing) {
        this.columns.resizing = null;
        document.body.style.cursor = "";
      }
      if (this.rows.resizing) {
        this.rows.resizing = null;
        document.body.style.cursor = "";
      }
    });
  }
}

//HANDLES SNAPSHOTS
class snapshot {
  getSnapShot() {}
  captureSnapShot() {}
}

//MANAGES FORMULA ENGINES
class FormulaEngine {
  evaluate(cell, data) {}
  parse(formula) {}
  updateDependencies(cell, formula) {}
}

//HANDLES CUSTOM CELL STYLING
class CellStyle {
  setStyle(cell, styleObj) {}
  getStyle(cell) {}
}

//MANAGES ALL EVENTS
class EventManager {
  constructor(container, spreadsheet) {
    this.container = container;
    this.sheet = spreadsheet;
  }

  attachEvents() {
    this.attachCanvasEvents();
    this.attachKeyboardEvents(); // Handle copy, paste, etc.
  }

  attachKeyboardEvents() {
    document.addEventListener("keydown", async (e) => {
      let cell = this.sheet.selection.focusCell;
      if (!this.sheet.selection.active) return;
      let handled = false;

      // Copy
      if (e.ctrlKey && e.key === "c") {
        this.sheet.clipboard.copy(
          this.sheet.selection.getSelectedCells(),
          this.sheet
        );
        e.preventDefault();
        handled = true;
      }

      // Paste
      if (e.ctrlKey && e.key === "v") {
        await this.sheet.clipboard.paste(
          this.sheet.selection.focusCell,
          this.sheet
        );
        e.preventDefault();
        handled = true;
      }
    });
  }

  attachCanvasEvents() {
    // --- Single-click to select cell ---
    this.sheet.canvas.addEventListener("click", (e) => {
      let rect = this.sheet.canvas.getBoundingClientRect();
      let mx = e.clientX - rect.left,
        my = e.clientY - rect.top;
      let col = this.sheet.viewport.findColByX(mx),
        row = this.sheet.viewport.findRowByY(my);
      if (col !== null && row !== null) {
        this.sheet.selection.selectCell(row, col); // Select the clicked cell
        this.sheet.render.renderGrid(); // Redraw the grid
      }
    });

    // --- Double-click to edit in-place ---
    this.sheet.canvas.addEventListener("dblclick", (e) => {
      let rect = this.sheet.canvas.getBoundingClientRect();
      let mx = e.clientX - rect.left,
        my = e.clientY - rect.top;
      let col = this.sheet.viewport.findColByX(mx),
        row = this.sheet.viewport.findRowByY(my);
      if (col !== null && row !== null) {
        this.sheet.selection.selectCell(row, col); // Select the double-clicked cell
        this.sheet.input.showInput(row, col); // Show input for that cell
      }
    });

    // --- Drag selection (mousedown, mousemove, mouseup) ---
    let isMouseDown = false;
    let startCell = null;

    this.sheet.canvas.addEventListener("mousedown", (e) => {
      let rect = this.sheet.canvas.getBoundingClientRect();
      let mx = e.clientX - rect.left,
        my = e.clientY - rect.top;
      let col = this.sheet.viewport.findColByX(mx),
        row = this.sheet.viewport.findRowByY(my);
      
      if (col !== null && row !== null) {
        startCell = { row, col }; // Store the starting cell for range selection
        this.sheet.selection.selectCell(row, col); // Select the clicked cell
        isMouseDown = true;
        this.sheet.render.renderGrid(); // Redraw the grid
      }
    });

    this.sheet.canvas.addEventListener("mousemove", (e) => {
      if (isMouseDown && startCell) {
        let rect = this.sheet.canvas.getBoundingClientRect();
        let mx = e.clientX - rect.left,
          my = e.clientY - rect.top;
        let col = this.sheet.viewport.findColByX(mx),
          row = this.sheet.viewport.findRowByY(my);
        
        if (col !== null && row !== null) {
          this.sheet.selection.selectRange(
            startCell.row, 
            startCell.col, 
            row, 
            col
          ); // Select range of cells
          this.sheet.render.renderGrid(); // Redraw the grid
        }
      }
    });

    this.sheet.canvas.addEventListener("mouseup", () => {
      isMouseDown = false; // Stop dragging when mouse is released
      this.sheet.render.renderGrid(); // Ensure the grid is rendered with the final selection
    });

    // Mouse wheel for virtual scroll
    this.sheet.canvas.addEventListener("wheel", (e) => {
      if (e.ctrlKey) return; // zoom
      e.preventDefault();
      if (e.shiftKey) {
        this.sheet.scrollCol = Math.min(
          Math.max(0, this.sheet.scrollCol + (e.deltaY > 0 ? 1 : -1)),
          Config.COLS - 1
        );
      } else {
        this.sheet.scrollRow = Math.min(
          Math.max(0, this.sheet.scrollRow + (e.deltaY > 0 ? 1 : -1)),
          Config.ROWS - 1
        );
      }
      this.sheet.render.renderGrid();
    }, { passive: true });
  }
}

//MANAGES IMPORTING AND EXPORTING FILES
class FileManager {
  import(file) {}
  export(format) {}
}

// --- INIT ---
document.addEventListener("DOMContentLoaded", () => {
  window.spreadsheet = new Spreadsheet("sheet-canvas");
});
